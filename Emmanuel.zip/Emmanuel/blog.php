<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Blog - Tassimo Academy</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <h1>Blog</h1>

        <?php
        $conn = new mysqli('localhost', 'root', '', 'Emmanuel15');
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Afficher les articles du blog
        $result = $conn->query("SELECT * FROM posts ORDER BY creation_date DESC");
        while ($post = $result->fetch_assoc()) {
            echo '<div class="post">';
            echo '<h2>' . htmlspecialchars($post['title']) . '</h2>';
            echo '<p>' . nl2br(htmlspecialchars($post['content'])) . '</p>';
            echo '<a href="post.php?id=' . $post['id'] . '">Lire la suite</a>';
            echo '</div>';
        }

        $conn->close();
        ?>
    </div>
</body>
</html>
