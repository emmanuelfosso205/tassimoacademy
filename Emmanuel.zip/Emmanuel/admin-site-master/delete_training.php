<?php
// delete_training.php

// Database connection
include 'db_connect.php';

$id = $_GET['id'];

$sql = "DELETE FROM in_person_training WHERE id=$id";

if ($conn->query($sql) === TRUE) {
    echo "Formation supprimée avec succès!";
} else {
    echo "Erreur: " . $conn->error;
}
?>
