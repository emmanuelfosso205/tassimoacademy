<?php
// edit_training.php

// Database connection
include 'db_connect.php';

$id = $_GET['id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $registration_deadline = $_POST['registration_deadline'];
    $start_date = $_POST['start_date'];

    // Handle file upload
    $flyer = $_POST['existing_flyer'];
    if (isset($_FILES['flyer']) && $_FILES['flyer']['error'] == 0) {
        $upload_dir = 'uploads/';
        $upload_file = $upload_dir . basename($_FILES['flyer']['name']);
        move_uploaded_file($_FILES['flyer']['tmp_name'], $upload_file);
        $flyer = basename($_FILES['flyer']['name']);
    }

    $sql = "UPDATE in_person_training SET 
            title='$title', 
            description='$description', 
            flyer='$flyer', 
            price=$price, 
            registration_deadline='$registration_deadline', 
            start_date='$start_date' 
            WHERE id=$id";

    if ($conn->query($sql) === TRUE) {
        echo "Formation modifiée avec succès!";
    } else {
        echo "Erreur: " . $conn->error;
    }
}

$sql = "SELECT * FROM in_person_training WHERE id=$id";
$result = $conn->query($sql);
$row = $result->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier formation presentiel</title>
    <link rel="stylesheet" href="stylespres.css">
</head>
<body>

</body>
<form action="edit_training.php?id=<?php echo htmlspecialchars($row['id']); ?>" method="post" enctype="multipart/form-data">
    <label for="title">Titre:</label>
    <input type="text" id="title" name="title" value="<?php echo htmlspecialchars($row['title']); ?>" required>
    <label for="description">Description:</label>
    <textarea id="description" name="description" required><?php echo htmlspecialchars($row['description']); ?></textarea>
    <label for="flyer">Flyer:</label>
    <input type="file" id="flyer" name="flyer">
    <input type="hidden" name="existing_flyer" value="<?php echo htmlspecialchars($row['flyer']); ?>">
    <label for="price">Prix d'inscription:</label>
    <input type="number" id="price" name="price" step="0.01" value="<?php echo htmlspecialchars($row['price']); ?>" required>
    <label for="registration_deadline">Date limite d'inscription:</label>
    <input type="date" id="registration_deadline" name="registration_deadline" value="<?php echo htmlspecialchars($row['registration_deadline']); ?>" required>
    <label for="start_date">Date de début:</label>
    <input type="date" id="start_date" name="start_date" value="<?php echo htmlspecialchars($row['start_date']); ?>" required>
    <input type="submit" value="Modifier Formation">
</form>

</body>
</html>
