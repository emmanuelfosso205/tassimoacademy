<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Modifier une Formation</title>
    <link rel="stylesheet" href="styles.css">
    <script src="scripts.js" defer></script>
</head>
<body>
    <div class="container">
        <h1>Modifier une Formation</h1>
        <?php
        $conn = new mysqli('localhost', 'root', '', 'Emmanuel15');
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        if (isset($_GET['id'])) {
            $id = $_GET['id'];
            $result = $conn->query("SELECT * FROM courses WHERE id=$id");
            $course = $result->fetch_assoc();
        }

        if (isset($_POST['submit'])) {
            $id = $_POST['id'];
            $name = $_POST['name'];
            $category = $_POST['category'];
            $price = $_POST['price']; // Ajouter le prix
            $flyer = $_FILES['flyer']['name'];
            $link = $_POST['link'];
            $description = $_POST['description']; // Ajouter la description

            if ($flyer) {
                $target_dir = "uploads/";
                $target_file = $target_dir . basename($flyer);
                move_uploaded_file($_FILES['flyer']['tmp_name'], $target_file);
                $sql = "UPDATE courses SET name=?, category=?, price=?, flyer=?, link=?, description=? WHERE id=?";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("ssdsssi", $name, $category, $price, $flyer, $link, $description, $id);
            } else {
                $sql = "UPDATE courses SET name=?, category=?, price=?, link=?, description=? WHERE id=?";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("ssdssi", $name, $category, $price, $link, $description, $id);
            }

            if ($stmt->execute()) {
                echo "Formation mise à jour avec succès.";
            } else {
                echo "Erreur: " . $stmt->error;
            }

            $stmt->close();
        }
        ?>
        <form action="modifier_formation.php?id=<?php echo $id; ?>" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="id" value="<?php echo htmlspecialchars($course['id']); ?>">
            
            <label for="name">Nom de la formation:</label>
            <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($course['name']); ?>" required>

            <label for="category">Catégorie:</label>
            <input type="text" id="category" name="category" value="<?php echo htmlspecialchars($course['category']); ?>" required>

            <label for="price">Prix:</label>
            <input type="text" id="price" name="price" value="<?php echo htmlspecialchars($course['price']); ?>" required>

            <label for="flyer">Flyer:</label>
            <input type="file" id="flyer" name="flyer" accept="image/*">

            <label for="link">Lien Drive:</label>
            <input type="text" id="link" name="link" value="<?php echo htmlspecialchars($course['link']); ?>" required>

            <label for="description">Description:</label>
            <textarea id="description" name="description" rows="4" required><?php echo htmlspecialchars($course['description']); ?></textarea>

            <button type="submit" name="submit">Mettre à jour</button>
        </form>
    </div>
</body>
</html>
