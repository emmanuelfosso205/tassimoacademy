<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Ajouter une Formation</title>
    <link rel="stylesheet" href="styles.css">
    <script src="scripts.js" defer></script>
</head>
<body>
    <div class="container">
        <h1>Ajouter une Formation</h1>
        <form action="ajouter_formation.php" method="POST" enctype="multipart/form-data">
            <label for="name">Nom de la formation:</label>
            <input type="text" id="name" name="name" required>

            <label for="category">Catégorie:</label>
            <select id="category" name="category" required>
                <?php
                // Connexion à la base de données
                $conn = new mysqli('localhost', 'root', '', 'Emmanuel15');
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                // Récupérer les catégories depuis la base de données
                $result = $conn->query("SELECT * FROM category");
                if ($result->num_rows > 0) {
                    // Afficher chaque catégorie dans une option du menu déroulant
                    while ($row = $result->fetch_assoc()) {
                        echo "<option value='" . $row['id'] . "'>" . $row['name'] . "</option>";
                    }
                } else {
                    echo "<option value=''>Aucune catégorie disponible</option>";
                }

                $conn->close();
                ?>
            </select>

            <label for="price">Prix:</label>
            <input type="text" id="price" name="price" required>

            <label for="flyer">Flyer:</label>
            <input type="file" id="flyer" name="flyer" accept="image/*" required>

            <label for="link">Lien Drive:</label>
            <input type="text" id="link" name="link" required>

            <label for="description">Description:</label>
            <textarea id="description" name="description" rows="4" required></textarea>

            <button type="submit" name="submit">Ajouter</button>
        </form>
    </div>
    <?php

    if (isset($_POST['submit'])) {
        $name = $_POST['name'];
        $category = $_POST['category'];
        $price = $_POST['price'];
        $flyer = $_FILES['flyer']['name'];
        $link = $_POST['link'];
        $description = htmlspecialchars($_POST['description']); // Échapper les caractères spéciaux sans <br />
    
        // Upload flyer
        $target_dir = "uploads/";
        if (!is_dir($target_dir)) {
            mkdir($target_dir, 0777, true); // Crée le répertoire avec les permissions appropriées s'il n'existe pas
        }
        $target_file = $target_dir . basename($flyer);
    
        if (move_uploaded_file($_FILES['flyer']['tmp_name'], $target_file)) {
            // Connexion à la base de données
            $conn = new mysqli('localhost', 'root', '', 'Emmanuel15');
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }
    
            // Préparer et exécuter la requête d'insertion
            $stmt = $conn->prepare("INSERT INTO courses (name, category, price, flyer, link, description) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("sissss", $name, $category, $price, $flyer, $link, $description);
    
            if ($stmt->execute()) {
                echo "Formation ajoutée avec succès.";
            } else {
                echo "Erreur: " . $stmt->error;
            }
    
            $stmt->close();
            $conn->close();
        } else {
            echo "Désolé, une erreur s'est produite lors du téléchargement de votre fichier.";
        }
    }
    ?>
    
</body>
</html>
