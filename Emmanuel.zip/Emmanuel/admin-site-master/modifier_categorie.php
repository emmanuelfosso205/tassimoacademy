<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Modifier une Catégorie</title>
    <link rel="stylesheet" href="styles.css1">
    <script src="scripts.js" defer></script>
</head>
<body>
    <div class="container">
        <h1>Modifier une Catégorie</h1>
        <?php
        $conn = new mysqli('localhost', 'root', '', 'Emmanuel15');
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        if (isset($_GET['id'])) {
            $id = $_GET['id'];
            $result = $conn->query("SELECT * FROM category WHERE id=$id");
            $category = $result->fetch_assoc();
        }

        if (isset($_POST['submit'])) {
            $id = $_POST['id'];
            $name = $_POST['name'];

            $sql = "UPDATE category SET name='$name' WHERE id=$id";

            if ($conn->query($sql) === TRUE) {
                echo "Catégorie mise à jour avec succès.";
            } else {
                echo "Erreur: " . $sql . "<br>" . $conn->error;
            }
        }
        ?>
        <form action="modifier_categorie.php?id=<?php echo $id; ?>" method="POST">
            <input type="hidden" name="id" value="<?php echo $category['id']; ?>">
            <label for="name">Nom de la catégorie:</label>
            <input type="text" id="name" name="name" value="<?php echo $category['name']; ?>" required>
            <button type="submit" name="submit">Mettre à jour</button>
        </form>
    </div>
</body>
</html>
