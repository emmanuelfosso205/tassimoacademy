<?php
// manage_trainings.php

// Database connection
include 'db_connect.php';

// Fetch training sessions from the database
$sql = "SELECT * FROM in_person_training ORDER BY start_date ASC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gérer Formations en Présentiel</title>
    <link rel="stylesheet" href="styles.css"> <!-- Link to your CSS file -->
</head>
<body>
    <header>
        <h1>Gérer Formations en Présentiel</h1>
        <a href="add_training.php">Ajouter une Formation</a>
    </header>
    
    <main>
        <?php if ($result->num_rows > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th>Titre</th>
                        <th>Description</th>
                        <th>Prix</th>
                        <th>Date limite</th>
                        <th>Date de début</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['title']); ?></td>
                        <td><?php echo htmlspecialchars(substr($row['description'], 0, 50)); ?>...</td>
                        <td>€<?php echo htmlspecialchars($row['price']); ?></td>
                        <td><?php echo htmlspecialchars($row['registration_deadline']); ?></td>
                        <td><?php echo htmlspecialchars($row['start_date']); ?></td>
                        <td>
                            <a href="edit_training.php?id=<?php echo htmlspecialchars($row['id']); ?>">Éditer</a>
                            <a href="delete_training.php?id=<?php echo htmlspecialchars($row['id']); ?>" onclick="return confirm('Êtes-vous sûr de vouloir supprimer cette formation ?');">Supprimer</a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>Aucune formation en présentiel à afficher.</p>
        <?php endif; ?>
    </main>
    
    <footer>
        <p>&copy; 2024 Tassimo Academy</p>
    </footer>
</body>
</html>
