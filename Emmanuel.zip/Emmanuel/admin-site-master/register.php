<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['register'])) {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $whatsapp = $_POST['whatsapp'];

    // Connexion à la base de données
    $conn = new mysqli('localhost', 'root', '', 'Emmanuel15');
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Préparer et exécuter la requête d'insertion
    $stmt = $conn->prepare("INSERT INTO admin (username, email, password) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $username, $email, $password);

    if ($stmt->execute()) {
        echo "Admin enregistré avec succès.";
    } else {
        echo "Erreur lors de l'enregistrement de l'admin: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>
