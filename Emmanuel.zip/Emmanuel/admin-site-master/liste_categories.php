<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Liste des Catégories</title>
    <link rel="stylesheet" href="styles1.css">
    <script src="scripts.js" defer></script>
</head>
<body>
    <div class="container">
        <h1>Liste des Catégories</h1>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nom</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $conn = new mysqli('localhost', 'root', '', 'Emmanuel15');
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                $result = $conn->query("SELECT * FROM category");
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $row['id'] . "</td>";
                    echo "<td>" . $row['name'] . "</td>";
                    echo "<td><a href='modifier_categorie.php?id=" . $row['id'] . "'>Modifier</a> | <a href='supprimer_categorie.php?id=" . $row['id'] . "'>Supprimer</a></td>";
                    echo "</tr>";
                }
                $conn->close();
                ?>
            </tbody>
        </table>
        <a href="ajouter_categorie.php">Ajouter une nouvelle catégorie</a>
    </div>
</body>
</html>
