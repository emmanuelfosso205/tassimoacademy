<?php
// liste_messages.php
session_start();
$conn = new mysqli('localhost', 'root', '', 'Emmanuel15');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch messages from database
$sql = "SELECT m.*, u1.username AS sender, u2.username AS receiver 
        FROM messages m 
        JOIN users u1 ON m.sender_id = u1.id 
        JOIN users u2 ON m.receiver_id = u2.id";
$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="style.css">
    <title>Liste des Messages</title>
</head>
<body>
<section id="sidebar">
    <!-- Sidebar code remains the same -->
</section>

<section id="content">
    <nav>
        <!-- Navbar code remains the same -->
    </nav>

    <main>
        <h1 class="title">Liste des Messages</h1>
        <ul class="breadcrumbs">
            <li><a href="admin_dashboard.php">Dashboard</a></li>
            <li class="divider">/</li>
            <li><a href="#" class="active">Messages</a></li>
        </ul>
        <div class="data">
            <div class="content-data">
                <div class="head">
                    <h3>Messages</h3>
                </div>
                <div class="table">
                    <table>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Expéditeur</th>
                                <th>Destinataire</th>
                                <th>Contenu</th>
                                <th>Date de Création</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($row = $result->fetch_assoc()): ?>
                            <tr>
                                <td><?= $row['id']; ?></td>
                                <td><?= $row['sender']; ?></td>
                                <td><?= $row['receiver']; ?></td>
                                <td><?= $row['content']; ?></td>
                                <td><?= $row['creation_date']; ?></td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>
</section>

<script src="script.js"></script>
</body>
</html>
